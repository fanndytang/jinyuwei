<?php
return [
    'SHOW_PAGE_TRACE' => false,//调试
    
    'MODULE_ALLOW_LIST' => ['Home','Panel', 'Adowner', 'Spreader'], // 配置分组列表
    'DEFAULT_MODULE' => 'Home', // 配置默认分组
    
    'DB_PARAMS' => [\PDO::ATTR_CASE => \ PDO::CASE_NATURAL],
    'DB_TYPE' => 'mysql', //数据库类型
    'DB_HOST' => '192.168.0.250', //数据库地址
    'DB_PORT' => '3306', //数据库端口
    'DB_PREFIX' => 'w_', //数据库前缀
    'DB_USER' => 'wzt', //数据库用户
    'DB_PWD' => 'wzt12300', //数据库密码
    'DB_NAME' => 'wzt', //数据库名
    
    'SITE_NAME' => '人人经济 - 波士邦', //设置站点名
    'SESSION_AUTO_START' => true,    // 初始化开启Session
    'SITE_DOMAIN' => 'bossbond.local.com:81', //设置网站域名
    'SURL' => 'http://bossbond.local.com:81',
    'MURL' => 'http://bossbond.local.com',
    
    'URL_CASE_INSENSITIVE' => true, //URL不区分大小写
    'URL_ROUTER_ON' => true,  //开启路由
    'URL_ROUTE_RULES' =>
        [
            'code/:router' => ['Pro/Index/index'],
            'p/:router' => ['Pro/Index/index'],
            'logout' => ['Home/User/logout']
        ],
    
    'USER_ADMINISTRATOR' => [1, 1187, 1121, 244],
    
    'UPLOAD_CONFIG' => [
        'savePath' => ['/files/', '/images/'],
    ],
    'FILE_UPLOAD_CONFIG' => [
        'saveName' => time() . '_' . mt_rand(),
        'rootPath' => './Uploads/', // 设置附件上传根目录
        'savePath' => '/files/', //保存路径
        'allowFiles' => ['.rar', '.zip', '.pdf', '.txt'], //文件允许格式
        'maxSize' => 10 * 1024 * 1024, //文件大小限制，单位KB
        'subName' => ['date', 'Ymd']
    ],
    'IMAGE_UPLOAD_CONFIG' => [
        'saveName' => time() . '_' . mt_rand(),
        'rootPath' => './Uploads/', // 设置附件上传根目录
        'savePath' => '/images/', //保存路径
        'exts' => ['jpg', 'gif', 'png', 'jpeg'],
        'maxSize' => 2 * 1024 * 1024,
        'subName' => ['date', 'Ymd']
    ] ,

    //邮件配置
    'EMAIL_CONFIG' => [
        'SMTP_HOST' => 'smtp.163.com', //SMTP服务器
        'SMTP_PORT' => '25', //SMTP服务器端口
        'SMTP_USER' => 'xxx@163.com', //SMTP服务器用户名
        'SMTP_PASS' => 'xxxxxxx', //SMTP服务器密码
        'FROM_EMAIL' => 'manyuanfw@163.com', //发件人EMAIL
        'FROM_NAME' => 'BOSSBOND', //发件人名称
        'REPLY_EMAIL' => '', //回复EMAIL（留空则为发件人EMAIL）
        'REPLY_NAME' => '', //回复名称（留空则为发件人名称）
    ]
];