<?php
// 检测PHP环境
if(version_compare(PHP_VERSION,'5.3.0','<'))  die('require PHP > 5.3.0 !');

define('IN_FOXPHP',TRUE);

define('WZT_PATH',preg_replace("/\\\/", "/", dirname(__FILE__) ) );

// 开启调试模式 建议开发阶段开启 部署阶段注释或者设为false
define('APP_DEBUG',true);
define('RUNTIME_PATH','./Runtime/');
//资源样式目录
define('AURL','/assets' );                                    //资源目录 样式 JS 

define('APP_SHOW_HOOK',false);  //显示模板钩子 使用时 关闭 false 查看时 true

define('APP_PATH','./Apps/');

define('APP_STATUS','ljh');
include './Data/slog/slog.function.php';
//配置
//slog(array(
//    'host'                => 'localhost',//websocket服务器地址，默认localhost
//    'optimize'            => false,//是否显示利于优化的参数，如果运行时间，消耗内存等，默认为false
//    'show_included_files' => false,//是否显示本次程序运行加载了哪些文件，默认为false
//    'error_handler'       => false,//是否接管程序错误，将程序错误显示在console中，默认为false
//    'force_client_ids'    => array(//日志强制记录到配置的client_id,默认为空,client_id必须在allow_client_ids中
//        //'client_01',
//        //'client_02',
//    ),
//    'allow_client_ids'    => array(//限制允许读取日志的client_id，默认为空,表示所有人都可以获得日志。
//        'client_01',
//        //'client_02',
//        //'client_03',
//    ),
//),'config');
@require './ThinkPHP/ThinkPHP.php';
